Feedback, Support, and Contributions
====================================

To contribute to meshoid, report an issue, or seek support, please initiate a pull request or issue through the project `project github <https://github.com/mikegrudic/meshoid>`_
